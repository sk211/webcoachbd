<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>ভুল: 404 Kunena view &#039;connectionphp&#039; not found</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="/templates/protostar/css/template.css" type="text/css" />
	<link rel="stylesheet" href="/templates/protostar/css/custom.css" type="text/css" />

			<link href="/templates/protostar/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
		<style type="text/css">
		body.site
		{
			border-top: 3px solid #0099cc;
			background-color: #ffffff		}
		a
		{
			color: #0099cc;
		}
		.navbar-inner, .nav-list > .active > a, .nav-list > .active > a:hover, .dropdown-menu li > a:hover, .dropdown-menu .active > a, .dropdown-menu .active > a:hover, .nav-pills > .active > a, .nav-pills > .active > a:hover
		{
			background: #0099cc;
		}
		.navbar-inner
		{
			-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
			-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
			box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
		}
	</style>
		<!--[if lt IE 9]>
		<script src="/media/jui/js/html5.js"></script>
	<![endif]-->
</head>

<body class="site com_kunena view-connection.php layout-default no-task itemid-516 fluid">

	<!-- Body -->
	<div class="body">
		<div class="container-fluid">
			<!-- Header -->
			<div class="header">
				<div class="header-inner clearfix">
					<a class="brand pull-left" href="">
						<span class="site-title" title="Webcoachbd">echo &quot;এবার ঘরে বসে হোন ডেভলপার&quot;;</span>					</a>
					<div class="header-search pull-right">
						<div class="search">
	<form action="/forum" method="post" class="form-inline">
		<label for="mod-search-searchword" class="element-invisible">Search...</label> <input name="searchword" id="mod-search-searchword" maxlength="20"  class="inputbox search-query" type="text" size="40" value="টিউটোরিয়াল খুজুন (বাংলায়)"  onblur="if (this.value=='') this.value='টিউটোরিয়াল খুজুন (বাংলায়)';" onfocus="if (this.value=='টিউটোরিয়াল খুজুন (বাংলায়)') this.value='';" /> <button class="button btn btn-primary" onclick="this.form.searchword.focus();">অনুসন্ধান</button>		<input type="hidden" name="task" value="search" />
		<input type="hidden" name="option" value="com_search" />
		<input type="hidden" name="Itemid" value="516" />
	</form>
</div>
					</div>
				</div>
			</div>
			<div class="navbar navbar-inverse">
				<div class="navbar-inner">
					<button data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar" type="button">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				<ul class="nav menu">
<li class="item-516 current active deeper parent"><a href="/forum" >ফোরাম</a><ul class="nav-child unstyled small"><li class="item-517"><a href="/forum/index" >নীড়পাতা</a></li><li class="item-518"><a href="/forum/recent" >সর্বশেষ বিষয়গুলি</a></li><li class="item-519"><a href="/forum/newtopic" >নতুন টপিক</a></li><li class="item-520"><a href="/forum/noreplies" >উত্তর হয়নি</a></li><li class="item-521"><a href="/forum/mylatest" >আমার টপিকগুলি</a></li><li class="item-522"><a href="/forum/profile" >প্রোফাইল</a></li><li class="item-524"><a href="/forum/search" >অনুসন্ধান</a></li></ul></li></ul>
<ul class="nav menu">
<li class="item-119"><a href="/project-page" >প্রজেক্ট</a></li><li class="item-373"><a href="webcoachbdEditor/onlineEditor.php" target="_blank" > কোড এডিটর</a></li><li class="item-583"><a href="/tips-guru" >টিপসগুরু</a></li><li class="item-566"><a href="/co-operation" >সহযোগিতা করুন</a></li><li class="item-115"><a href="/about-us" >আমাদের সম্পর্কে</a></li></ul>
				</div>
			</div>
			<!-- Banner -->
			<div class="banner">
							</div>
			<div class="row-fluid">
				<div id="content" class="span12">
					<!-- Begin Content -->
					<h1 class="page-header">অনুরোধকৃত পেজটি পাওয়া যায়নি।</h1>
					<div class="well">
						<div class="row-fluid">
							<div class="span6">
								<p><strong>আপনার অনুরোধ প্রসেসের সময় একটি ভুল হয়েছে।</strong></p>
								<p>আপনি এই পেজটি দেখতে পারবেন না কারন:</p>
								<ul>
									<li>একটি <strong>পুরোনো ফুরিয়ে যাওয়া বুকমার্ক/প্রিয় বা ফেভারিট</strong></li>
									<li><strong>ঠিকানা ভুল টাইপ করেছেন</strong></li>
									<li>এমন কোন সার্চ ইন্জিন থেকে এখানে এসেছেন <strong>যে ইন্জিন আমাদের সাইটের সরিয়ে ফেলা কোন পুরোনো কনটেন্টের ঠিকানা এখনও ধরে রেখেছে।</strong></li>
									<li>আপনার <strong>অনুমতি নেই</strong> এই পেজ দেখার জন্য</li>
								</ul>
							</div>
							<div class="span6">
																	<p><strong>আপনি সাইটের নীড়ে ফিরে যেতে পারেন কিংবা এখানে কিছু অনুসন্ধান করতে পারেন।</strong></p>
									<p>এই সাইটে অনুসন্ধান করুন</p>
									<div class="search">
	<form action="/forum" method="post" class="form-inline">
		<label for="mod-search-searchword" class="element-invisible">Search...</label> <input name="searchword" id="mod-search-searchword" maxlength="20"  class="inputbox search-query" type="text" size="40" value="টিউটোরিয়াল খুজুন (বাংলায়)"  onblur="if (this.value=='') this.value='টিউটোরিয়াল খুজুন (বাংলায়)';" onfocus="if (this.value=='টিউটোরিয়াল খুজুন (বাংলায়)') this.value='';" /> <button class="button btn btn-primary" onclick="this.form.searchword.focus();">অনুসন্ধান</button>		<input type="hidden" name="task" value="search" />
		<input type="hidden" name="option" value="com_search" />
		<input type="hidden" name="Itemid" value="516" />
	</form>
</div>
																<p>নীড় পাতায় ফিরে যান</p>
								<p><a href="/index.php" class="btn"><i class="icon-home"></i> নীড়পাতা</a></p>
							</div>
						</div>
						<hr />
						<p>যদি খুব সমস্যা মনে হয়, অনুগ্রহপূর্বক সাইটের এডমিনের সাথে যোগাযোগ করুন এবং এই ভুল সম্পর্কে জানান। (refatju AT yahoo DOT com)</p>
						<blockquote>
							<span class="label label-inverse">404</span> Kunena view &#039;connectionphp&#039; not found						</blockquote>
					</div>
					<!-- End Content -->
				</div>
			</div>
		</div>
	</div>
	<!-- Footer -->
	<div class="footer">
		<div class="container-fluid">
			<hr />
			<div class="footer1 pull-left">কপিরাইট &#169; 2015 Webcoachbd. সর্বস্বত্ব সংরক্ষিত। হোস্টিং স্পন্সর <a target="_blank" href="https://www.w3space.net/bn">W3space Technologies</a></div>			<p class="pull-right">
				<a href="#top" id="back-top">
					উপরে যান				</a>
			</p>
			<p>
				&copy; 2015 Webcoachbd			</p>
		</div>
	</div>
	</body>
</html>
