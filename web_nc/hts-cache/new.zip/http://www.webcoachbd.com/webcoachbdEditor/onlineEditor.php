<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
     <title>Webcoachbd Code Editor | Version 1.2 </title>
     <link rel="stylesheet" type="text/css" href="bootstrap.min.css" />
     <link rel="stylesheet" type="text/css" href="stylesheet.css" />
    </head>
    <body>
		<div class="container">
		<div class="row header_panel">
			<h1>ওয়েবকোচবিডি অনলাইন কোড এডিটর</h1>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 well">
				<div class="col-lg-6 col-md-6 col-sm-6">
					<form style="margin:0px" action="launch_code.php" method="post" target="view">
						<div class="form-group">
							<p><input style="font-family:verdana;" class="btn btn-success" name="submit" type="submit" value="Edit and Hit"> কোড লিখে "Edit and Hit" বাটনে ক্লিক করুন</p>
							<textarea class="form-control" width="100%" rows="18" height="400px" name="code"></textarea>
						</div>
						
					</form>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 right_pane">
					<p class="text-info">Output:</p>
					<iframe class="result_output" width="100%" height="393px" name="view" src="launch_code.php"></iframe>
				</div>
			</div>
		</div>
		<div class="row footer">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<p>Copyright &copy; <a href="http://www.webcoachbd.com">Webcoachbd</a> 2015</p>
			</div>
		</div>
	</div>
    </body>
</html>